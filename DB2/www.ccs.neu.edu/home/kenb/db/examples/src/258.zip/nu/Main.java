package nu;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 * Main program to test the band data model.
 */
public class Main {
    /** Factory for constructing entity managers. */
    static EntityManagerFactory factory;

    /**
     * Test program.
     * @param args The command-line arguments. None are used.
     */
    public static void main(String[] args){

        // Establish a connection

        Map<Object, Object> map = new HashMap<Object,Object>();
        map.put("openjpa.ConnectionUserName", "root");
        map.put("openjpa.ConnectionPassword", "abcd");
        map.put("openjpa.ConnectionURL", "jdbc:mysql://localhost/test");
        map.put("openjpa.ConnectionDriverName", "com.mysql.jdbc.Driver");
        map.put("openjpa.jdbc.SynchronizeMappings", "buildSchema");
        factory = Persistence.createEntityManagerFactory("musicians", map);
        EntityManager manager = factory.createEntityManager();

        // Create a person and band.

        Person fred = new Person("Fred");
        Person mary = new Person("Mary");
        Band band = new Band("The Stoics", "stern");
        band.addMusician(fred);
        band.addMusician(mary);

        // Persist the band.

        manager.getTransaction().begin();
        manager.persist(band);
        manager.getTransaction().commit();
        System.out.println(fred);
        System.out.println(mary);
        System.out.println(band);

        // Retrieve one of the persons

        TypedQuery<Person> q = manager.createQuery("select p from Person p where p.name = ?1", Person.class);
        q.setParameter(1, "Mary");
	Person p = q.getSingleResult();
        System.out.println(p);
    }
}
