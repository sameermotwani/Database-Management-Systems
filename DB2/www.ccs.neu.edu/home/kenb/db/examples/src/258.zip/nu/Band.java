package nu;

import javax.persistence.*;
import static javax.persistence.AccessType.FIELD;
import static javax.persistence.FetchType.EAGER;
import static javax.persistence.CascadeType.ALL;
import java.util.Set;
import java.util.HashSet;

/**
 * Band persistent entity.
 * <pre>
 * create table Band(
 *  id int primary key,
 *  name varchar(255),
 *  style int references Style(id)
 * );
 * </pre>
 * @author Ken Baclawski
 */
@Entity
@Access(FIELD)
public class Band{
    /** Primary key. */
    @Id
    @GeneratedValue
    public int id = 0;
    
    /** Name attribute. */
    @Column(name="name", length=255)
    public String name = null;
    
    /** Style attribute. */
    @ManyToOne(cascade=ALL, fetch=EAGER)
    @JoinColumn(name="style")
    public Style style = null;

    /**
     * memberOf association.
     * <pre>
     * create table memberOf(
     *  person int references Person(id),
     *  band int references Band(id),
     *  primary key(person, band)
     * );
     * </pre>
     * The name of the join table as well as its column
     * names are specified with the @JoinTable annotation.
     * The name of the Java field is "memberOf" and does not
     * correspond to anything in the database. The memberOf
     * attribute is used in queries, while the join table
     * name as well as the join table column names are
     * never used in queries.
     */
    @ManyToMany(cascade=ALL, fetch=EAGER)
    @JoinTable(name="memberOf",
               joinColumns=@JoinColumn(name="band"),
               inverseJoinColumns=@JoinColumn(name="person"))
    public Set<Person> members = null;

    /**
     * Construct a band with no field values.
     */
    public Band() {}

    /**
     * Construct a band with a name and style.
     * @param name The band name
     * @param style The band style
     */
    public Band(String name, String style) {
        this.name = name;
        this.style = new Style(style, style);
    }

    /**
     * Add member to the band. The inverse collection must also be updated. JPA
     * is not required to keep the collections consistent with each other.
     * @param musician The musician to add to the band.
     */
    public void addMusician(Person musician) {
        if (members == null) {
            members = new HashSet<Person>();
        }
        members.add(musician);
        if (musician.memberOf == null) {
            musician.memberOf = new HashSet<Band>();
        }
        musician.memberOf.add(this);
    }

    /**
     * Represent the band as a string.
     * @return The band in a readable form.
     */
    public String toString(){
         String representation = "Band name: " + name + " style: " + style + " members:";
         for (Person musician : members) {
             representation += " " + musician.name;
         }
         return representation;
    }
}
