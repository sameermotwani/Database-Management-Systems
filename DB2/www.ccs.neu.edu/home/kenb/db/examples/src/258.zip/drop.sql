drop database if exists test;
create database test;
