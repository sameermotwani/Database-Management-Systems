package nu;

import javax.persistence.*;
import static javax.persistence.AccessType.FIELD;
import static javax.persistence.FetchType.EAGER;
import java.util.Set;
import java.util.HashSet;

/**
 * Style persistent entity.
 * <pre>
 * create table Style(
 *  id int primary key,
 *  description varchar(20000)
 * );
 * </pre>
 * @author Ken Baclawski
 */
@Entity
@Access(FIELD)
public class Style{
    /** Primary key. */
    @Id
    @GeneratedValue
    public int id = 0;
   
    /** Description attribute. */
    @Column(length=20000)
    public String description = "";

    /**
     * Multivalued attribute names.
     * <pre>
     * create table StyleName(
     *   style int references Style(id),
     *   name varchar(200),
     *   primary key(name, style)
     * );
     * </pre>
     * Note that @Column(name="name") specifies the name
     * of the column in the collection table. The default
     * is "element". The other column of the collection
     * table is specified by joinColumns. The name of
     * the Java field is "names" and does not correspond
     * to anything in the database. The names
     * attribute is used in queries, while the join table
     * name as well as the join table column names are
     * never used in queries.
     * <p>
     * Setting fetch to EAGER ensures that when a type
     * is retrieved, the names set will also be retrieved.
     * By default, multivalued attributes are not retrieved.
     */
    @ElementCollection(fetch=EAGER)
    @Column(name="name")
    @CollectionTable(name="StyleName", joinColumns=@JoinColumn(name="style"))
    public Set<String> names = null;

    /**
     * Construct a style with no field values.
     */
    public Style() {}

    /**
     * Construct a style with a description and name.
     * @param description The description of the style
     * @param name One of the names of the band.
     */
    public Style(String description, String name) {
        this.description = description;
        names = new HashSet<String>();
        names.add(name);
    }

    /**
     * Represent the style as a string.
     * @return The style in a readable form.
     */
    public String toString(){ 
        String representation = "Style " + description + " {";
        for (String name : names) {
            representation += " " + name;
        }
        return representation + " }";
    }
}
