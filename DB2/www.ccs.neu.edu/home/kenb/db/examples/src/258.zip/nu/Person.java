package nu;

import javax.persistence.*;
import static javax.persistence.AccessType.FIELD;
import static javax.persistence.FetchType.EAGER;
import static javax.persistence.CascadeType.ALL;
import java.util.Set;
import java.util.HashSet;

/**
 * Person persistent entity.
 * <pre>
 * create table Person(
 * id int primary key,
 * name varchar(255) not null
 * );
 * </pre>
 * @author Ken Baclawski
 */
@Entity
@Access(FIELD)
public class Person {
    /** Primary key. */
    @Id
    @GeneratedValue
    public int id = 0;
 
    /** Name attribute. */
    @Column(name="name", length=255, nullable=false)
    public String name = null;

    /** Inverse of the members collection of Band. */
    @ManyToMany(cascade=ALL, fetch=EAGER, mappedBy="members")
    public Set<Band> memberOf = new HashSet<Band>();

    /**
     * Construct a person with no field values.
     */
    public Person() {}

    /**
     * Construct a person with a specified name.
     * @param name The name of the person.
     */
    public Person(String name) {
        this.name = name;
    }

    /**
     * Represent the person as a string.
     * @return The person in a readable form.
     */
    public String toString(){
         String representation = "Person id: " + id + " name: " + name + " member of:";
         for(Band b : memberOf){
             representation += " " + b.name;
         }
         return representation;
    }
}
