#!/bin/sh
#
# Compile and Run the OpenJPA test program
# Author: Ken Baclawski
#
cp=.
cp=$cp:lib/mysql-connector-java.jar
cp=$cp:lib/openjpa-all-2.2.2.jar
#
echo "Dropping existing database and recreating it"
mysql -u root -pabcd < drop.sql
echo "Compiling"
javac -cp $cp nu/*.java
echo "Enhancing"
java -cp $cp org.apache.openjpa.enhance.PCEnhancer nu/Person.java nu/Band.java nu/Style.java
echo "Running"
java -cp $cp nu.Main
