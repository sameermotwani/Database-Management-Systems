package nu;

import java.io.Serializable;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.Entity;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Basic;
import javax.persistence.ManyToMany;

@Entity
@Access(AccessType.PROPERTY)
public class Course implements Serializable {
    private int code;
    private String name;
    private String description;
    private Set<Student> roster = new HashSet<Student>();
    public static final long serialVersionUID = 1299942512498452602L;

    @Id @GeneratedValue
    public int getCode() {
        return code;
    }
    public void setCode (int code) {
        this.code = code;
    }

    @Basic
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @Basic
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    @ManyToMany(mappedBy="enrollment")
    public Set<Student> getRoster() {
        return roster;
    }
    public void setRoster(Set<Student> roster) {
        this.roster = roster;
    }

    public Course() {}
    public Course(String name, String description) {
        this.name = name;
        this.description = description;
    }
    public String toString() {
        return "Course " + getCode() + " " + getName() + " " + getDescription();
    }
}
