package nu;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.Entity;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Basic;
import javax.persistence.ManyToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;

@Entity
@Access(AccessType.PROPERTY)
public class Student implements Serializable {
    private String name;
    private String email;
    private Date matriculation;
    private Set<Course> enrollment = new HashSet<Course>();
    public static final long serialVersionUID = 1954837514335984225L;

    @Basic
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @Basic
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    @Basic @Temporal(TemporalType.DATE)
    public Date getMatriculation() {
        return matriculation;
    }
    public void setMatriculation(Date matriculation) {
        this.matriculation = matriculation;
    }

    @ManyToMany
    @JoinTable(name="Enrollment",
	       joinColumns=@JoinColumn(name="student"),
        inverseJoinColumns=@JoinColumn(name="course", referencedColumnName="code")
    )
    public Set<Course> getEnrollment() {
        return enrollment;
    }
    public void setEnrollment(Set<Course> enrollment) {
        this.enrollment = enrollment;
    }

    public Student() {}
    public Student(String name, String email) {
	this.name = name;
	this.email = email;
	this.matriculation = new Date();
    }
    public String toString() {
	return "Student " + getName() + " " + getEmail() + " year " + getMatriculation();
    }
}
