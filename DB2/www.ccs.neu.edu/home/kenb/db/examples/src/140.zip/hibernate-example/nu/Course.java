package nu;

import java.util.Set;
import java.util.HashSet;

/**
 * University Course class.
 * The Javadoc comments were omitted to make it easier to display the example.
 * @author Ken Baclawski
 */
public class Course {
    public int code;
    public String name;
    public String description;
    public Set<Student> roster = new HashSet<Student>();

    public Course() {}
    public Course(String name, String description) {
	this.name = name;
	this.description = description;
    }
    public String toString() {
	return "Course " + code + " " + name + " " + description;
    }
}
