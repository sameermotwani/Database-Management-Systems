package nu;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

/**
 * University Student class.
 * The Javadoc comments were omitted to make it easier to display the example.
 * @author Ken Baclawski
 */
public class Student {
    public int studentId;
    public String name;
    public String email;
    public Date matriculation;
    public Set<Course> enrollment = new HashSet<Course>();

    public Student() {}
    public Student(String name, String email) {
	this.name = name;
	this.email = email;
	this.matriculation = new Date();
    }
    public String toString() {
	return "Student " + studentId + " " + name + " " + email + " year " + matriculation;
    }
}
