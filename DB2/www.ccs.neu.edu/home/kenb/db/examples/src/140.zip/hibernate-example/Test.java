
import java.util.Date;
import java.text.SimpleDateFormat;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import nu.Student;
import nu.Course;

/**
 * Example of a Hibernate program.
 * @author Ken Baclawski
 */
public class Test {
    public static void main(String... argv) {
        try {
	    Student s = new Student("Fred", "fred@neu.edu");
	    Course c = new Course("CS5200", "Database Management");
	    s.enrollment.add(c);

            SessionFactory factory = new Configuration()
		.configure().buildSessionFactory();
	    Session session = factory.getCurrentSession();
	    session.beginTransaction();
	    session.save(s);
	    session.save(c);
	    session.getTransaction().commit();
	    // Note that committing the session closes the session.

	    // Iterate over all students, then courses.
	    session = factory.getCurrentSession();
	    session.beginTransaction();
	    for (Object list : session.createQuery
		     ("from Student s join s.enrollment e").list()) {
		for (Object o : (Object[])list) {
		    System.out.println(o);
		}
	    }
	    session.getTransaction().commit();

	    // Iterate over all courses, then students
	    session = factory.getCurrentSession();
	    session.beginTransaction();
	    for (Object list : session.createQuery
		     ("from Course c join c.roster s").list()) {
		for (Object o : (Object[])list) {
		    System.out.println(o);
		}
	    }
	    session.getTransaction().commit();

	    factory.close();
        }
        catch (Exception e) {
	    e.printStackTrace();
        }
    }
}
