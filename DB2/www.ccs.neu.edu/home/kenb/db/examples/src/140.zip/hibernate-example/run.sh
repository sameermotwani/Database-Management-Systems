#!/bin/sh
#
# Compile and Run the Hibernate test program
# This script assumes that the database already exists.
#
cp=.
cp=$cp:lib/hibernate3.jar # Main hibernate component
cp=$cp:lib/mysql-connector-java.jar # MySQL driver
cp=$cp:lib/dom4j.jar # Support for DOM, SAX, JAXP, XPath and XSLT
cp=$cp:lib/slf4j-log4j12.jar # Logging binding to log4j
cp=$cp:lib/slf4j-api.jar # Logging front end
cp=$cp:lib/log4j.jar # Logger itself
cp=$cp:lib/commons-collections-3.2.jar # Extension of the Java Collections Framework
cp=$cp:lib/jta.jar # Java Transactions API
cp=$cp:lib/javassist.jar # Java bytecode manipulator
cp=$cp:lib/javax.persistence.jar # JPA
cp=$cp:lib/antlr.jar # Parser
#
echo "Compiling"
javac -cp $cp Test.java
echo "Running"
java -cp $cp Test
